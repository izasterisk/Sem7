package vn.edu.fpt.jpos.repositories.entities.orderdetail;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class OrderDetailERROR extends IError {

    public OrderDetailERROR(String message) {
        super(message);
    }
}
