package vn.edu.fpt.jpos.repositories.entities.customerrequest;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class CustomerRequestERROR extends IError {

    public CustomerRequestERROR(String message) {
        super(message);
    }
}
