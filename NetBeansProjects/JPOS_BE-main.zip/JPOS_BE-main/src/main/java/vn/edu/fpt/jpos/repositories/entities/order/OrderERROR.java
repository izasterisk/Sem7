package vn.edu.fpt.jpos.repositories.entities.order;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class OrderERROR extends IError {
    public OrderERROR(String message) {
        super(message);
    }
}

