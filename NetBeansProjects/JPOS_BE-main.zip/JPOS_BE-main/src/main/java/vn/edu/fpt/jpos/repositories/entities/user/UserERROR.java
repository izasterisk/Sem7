package vn.edu.fpt.jpos.repositories.entities.user;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class UserERROR extends IError {

    public UserERROR(String message) {
        super(message);
    }

}
