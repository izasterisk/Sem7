package vn.edu.fpt.jpos.repositories.entities.token;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class TokenERROR extends IError {

    public TokenERROR(String message) {
        super(message);
    }
}
