package vn.edu.fpt.jpos.repositories.entities.category;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class CategoryERROR extends IError {

    public CategoryERROR(String message) {
        super(message);
    }
}
