package vn.edu.fpt.jpos.repositories.entities.product;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class ProductERROR extends IError {

    public ProductERROR(String message) {
        super(message);
    }
}
