package vn.edu.fpt.jpos.repositories.entities.staffresponse;

import vn.edu.fpt.jpos.repositories.entities.IError;

public class StaffResponseERROR extends IError {

    public StaffResponseERROR(String message) {
        super(message);
    }
}
